package servlets;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;

@WebServlet("/first")
public class FirstServlet implements Servlet {
    private ServletConfig servletConfig;

    //  Servlet LifeCycle Methods
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        this.servletConfig = servletConfig;
        System.out.println("Initialising First Servlet");
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("Servicing Request");
    }

    @Override
    public void destroy() {
        System.out.println("Destroying Servlet");
    }


//  Servlet Non-LifeCycle Methods

    @Override
    public ServletConfig getServletConfig() {
        return this.servletConfig;
    }

    @Override
    public String getServletInfo() {
        return "First Servlet is Created";
    }


}
