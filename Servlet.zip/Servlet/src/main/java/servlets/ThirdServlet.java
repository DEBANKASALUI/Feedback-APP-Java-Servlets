package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

@WebServlet("/third")
public class ThirdServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("HTTP doGetMethod from Third servlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String message = req.getParameter("message");
        System.out.println("Form submitted using doPost Method");
        System.out.println("Message:" + message);
//      Sending data to browser
        resp.setContentType("text/html");
        PrintWriter writer = resp.getWriter();
        writer.print("<h1>Form Submitted!</h2>");
        writer.print("<h2>Message: %s</h2>".formatted(message));
        writer.print("<h3>Submitted date: " + new Date() + "</h3>");
//        resp.setStatus(401);
    }
}
